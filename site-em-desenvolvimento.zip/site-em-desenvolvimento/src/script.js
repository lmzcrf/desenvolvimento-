// script.js

document.addEventListener('DOMContentLoaded', function() {
    const showContactFormBtn = document.getElementById('show-contact-form-btn');
    const contactFormSection = document.getElementById('contact-form-section');
    const contactForm = document.querySelector('.contact-form');

    // Funcionalidade para mostrar/esconder o formulário de contato
    if (showContactFormBtn && contactFormSection) {
        showContactFormBtn.addEventListener('click', function() {
            // Alterna a exibição do formulário
            if (contactFormSection.style.display === 'none' || contactFormSection.style.display === '') {
                contactFormSection.style.display = 'block';
                // Opcional: rolar para o formulário
                contactFormSection.scrollIntoView({ behavior: 'smooth' });
            } else {
                contactFormSection.style.display = 'none';
            }
        });
    }

    // Funcionalidade básica de "submit" para o formulário (apenas para simular no front-end)
    if (contactForm) {
        contactForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Impede o envio padrão do formulário (que recarregaria a página)

            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const message = document.getElementById('message').value;

            // Validação simples
            if (name && email && message) {
                alert(`Mensagem enviada!\nNome: ${name}\nEmail: ${email}\nMensagem: ${message}\n\n(No futuro, esta mensagem seria enviada para um servidor.)`);
                contactForm.reset(); // Limpa o formulário
                contactFormSection.style.display = 'none'; // Esconde o formulário
            } else {
                alert('Por favor, preencha todos os campos do formulário.');
            }
        });
    }

    // Funcionalidade para o botão "Leia Mais" (Exemplo - você pode expandir isso)
    const readMoreButtons = document.querySelectorAll('.btn-read-more');
    readMoreButtons.forEach(button => {
        button.addEventListener('click', function() {
            alert('Você clicou em "Leia Mais"! Aqui você poderia ir para uma página de post completa ou expandir o conteúdo.');
            // Em um site real, você navegaria para uma página de post detalhada.
            // window.location.href = '/post/id-do-post';
        });
    });
});
